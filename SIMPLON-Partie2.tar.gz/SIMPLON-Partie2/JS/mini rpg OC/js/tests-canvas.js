var smiley = new Image();
smiley.src = "https://cdn3.iconfinder.com/data/icons/communication-1/100/smiley_happy-512.png";


// Lance le jeu
// code JavaScript sera exécuté qu'une fois la page chargée complètement
window.onload = function() {
  // Cible le canva
  var canvas = document.getElementById('canvas');
  // récupére notre objet "context"
  var ctx = canvas.getContext('2d');

  ctx.fillStyle = 'blue';
  ctx.fillRect(10, 10, 100, 50);

  ctx.strokeStyle = 'red';
  ctx.strokeRect(75, 75, 50, 50);

// Emplacement sur x y
  ctx.drawImage(smiley, 200, 10);
// emplacement et taille
ctx.drawImage(smiley, 200, 10, 50 , 50);
// partie visible, emplacement et taille
  ctx.drawImage(smiley, 0,0, 200,500, 100, 20, 20, 20);

}
