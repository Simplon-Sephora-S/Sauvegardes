//nouvele objet de la classe tileset dapres le png
var ts = new Tileset('basique.png');


window.onload = function() {
  //Prend le canvas
  var canvas = document.getElementById('canvas');
  // Donne lui un environnemment 2d
  var ctx = canvas.getContext('2d');

  //sur basique.png, utilise la methode dessinerTile pour assembler les zones voulues
  // Nom de la zone decoupée + contexte + coordonées x +coordonnée y
  ts.dessinerTile(1, ctx, 10, 10);
  ts.dessinerTile(5, ctx, 50, 10);
  ts.dessinerTile(6, ctx, 90, 10);
  ts.dessinerTile(7, ctx, 130, 10);

  // Largeur du tileset en tiles
this.referenceDuTileset.largeur = this.width / 32;

var xSourceEnTiles = numero % this.largeur;
if(xSourceEnTiles == 0) xSourceEnTiles = this.largeur;

var ySourceEnTiles = Math.ceil(numero / this.largeur);

var xSource = (xSourceEnTiles - 1) * 32;
var ySource = (ySourceEnTiles - 1) * 32;

context.drawImage(this.image, xSource, ySource, 32, 32, xDestination, yDestination, 32, 32);

}
