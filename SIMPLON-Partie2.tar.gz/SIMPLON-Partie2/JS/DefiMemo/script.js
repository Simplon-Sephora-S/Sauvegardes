$(function(){
  // Styles des cartes
  // Verso (le même pour toute les cartes)
  var verso =  document.getElementsByClassName('f1_card');
  verso = $('.f1_card').css('background-color', "DarkSeaGreen");

  var carteConteneur = document.getElementsByClassName('f1_container');


  // Chiffre aléatoire qui détermine l'affichage de la couleur
  var rectoAleatoire = Math.floor(Math.random() * 5);
  console.log(rectoAleatoire);

  // Affiche les cartes
  var paire1 = $('.f1_container').appendTo('#scene');
  var paire2 = $('.f1_container').clone().appendTo('#scene');
  var paire3 = $('.f1_container').clone().appendTo('#scene');
  var paire4 = $('.f1_container').clone().appendTo('#scene');

  // Distribution aléatoire des rectos
  function paireAleatoire(rectoAleatoire){
    switch (rectoAleatoire) {
      case 0:
      paire1 = $('.face.back').css('background-color', "Lightgreen");
      break;
      case 1:
      paire2 = $('.face.back').css('background-color', "Coral");
      break;
      case 2:
      paire3 = $('.face.back').css('background-color', "GoldenRod");
      break;
      case 3:
      paire4 = $('.face.back').css('background-color', "FireBrick");
      break;
      default:
      $('.face.back').css('background-color', "Coral");
      break;
    }



    window.onload = function () {
      paireAleatoire(rectoAleatoire);


    }
  };



});
