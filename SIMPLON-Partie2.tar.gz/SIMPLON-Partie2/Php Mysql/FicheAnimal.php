<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Fiche animal</title>
</head>
<body>
  <h1>Identité de l'animal</h1>
  <!-- FORMULAIRE -->
  <form action="FicheAnimal.php" method="get">
    <p><input type="text" name="nom" value="Nom"></p>
    <p><input type="text" name="espece" value="Espèce"> </p>
    <!-- Liste déroulante, choix du sexe -->

    <select name= "sexe" id= "sexe">
      <option value="m">Mâle</opsexetion>
        <option value="f">Femelle</option>
      </select></p>



      <!-- Ajjouter la fonctionnalité date plus tard  -->
      <!-- <input type="datetime" value= "date_naissance">Naissance</code> -->

      <textarea name="commentaires" rows="8" cols="40">Commentaires</textarea>

      <p><input type="submit" value="Valider" /></p>
    </form>



    <?php





    // Connexion à la base de donnée
    // try{
    //   $bdd= new PDO('mysql:host=localhost;dbname=Animal;charset=utf8', 'root','');
    //   echo "connexion ok";
    // }
    // catch (Exception $e){
    //   die('Oups, erreur lors de la connexion à la base de donnée : ' . $e->getMessage());
    // }


    // Insertion dans la base de donnée"
$espece = $_GET['espece'];
$sexe = $_GET['sexe'];
$nom = $_GET['nom'];
$commentaires = $_GET['commentaires'];

    if( isset($_GET['espece']) && isset($_GET['sexe']) && isset($_GET['nom']) && isset($_GET['commentaires'])){
      $connexion = mysqli_connect('localhost', 'root','') or die('Erreur de connexion BDD');
      $requete = "INSERT INTO TableAnimal(`id`, `espece`,`sexe`, `nom`, `commentaires`) VALUES(NULL, 'TEST' , 'm' , 'zef' , 'ezfdsg')";
      $resultat = mysqli_query($connexion, $requete) or die ('Erreur de requête BDD');
      echo $requete === true ? 'Le nouvel animal a bien été ajouté.' : 'Erreur, animal non ajouté';
    }

    else {
      echo "Données invalides";
    }







    ?>

  </body>
  </html>
